#pragma include <surface.frag>

uniform vec3 u_baseColor;
uniform sampler2D u_normalTex;
uniform float u_normalIntensity;
uniform sampler2D u_reflectionTex;
uniform float u_reflectionIntensity;

//uniform float time;
uniform float u_alpha;
uniform float u_scrollSpeed;

void surface(inout Material material)
{
	//float scrollSpeed = 0.05;
	// normals
	vec3 normal_base1 = (texture(u_normalTex, vec2(mod(u_scrollSpeed * u_time, 1.0)) + v_texCoord).xyz - 0.5) * 2.0;
	vec3 normal_base2 = (texture(u_normalTex, vec2(mod(u_scrollSpeed * u_time * 1.1, 1.0)) - v_texCoord + vec2(0.5, 0.5)).xyz - 0.5) * 2.0;
	vec3 normal = normalize(vec3(normal_base1.xy + normal_base2.xy, normal_base1.z + normal_base2.z));
	normal.xy *= u_normalIntensity;
	material.normal = v_tanToWorld * normal;

	vec3 incidentRay = normalize(v_worldPos - u_eyePos);
    vec3 reflVec = reflect(incidentRay, material.normal);
	vec3 color = texture(u_reflectionTex, envMapEquirect(normalize(reflVec)) * vec2(1.0, -1.0)).rgb;
	//color *= u_reflectionIntensity;

	material.ambient = vec3(0.1);
	material.diffuse = u_baseColor * (1.0 - u_reflectionIntensity) + color * u_reflectionIntensity;
	//material.diffuse = vec3(normal.z);
	material.alpha = u_alpha;
	material.shininess = 50;
}