{
	"name" : "Water",
	"zWrite"        : true,
    "depthTest"     : true,
    "blendMode"     : "blend",
    "cullMode"      : "back",

    "renderLayer"   : "transparent",
    "fog"           : true,
    "castShadows"   : false,
    "receiveShadows": false,
    "lighting"      : true,
    "uniforms": [
        {
            "displayName"   : "Base Color",
            "name"          : "baseColor",
            "type"          : "color",
            "value"         : "#FFF",
            "uniform"       : "u_baseColor"
        }, {
            "displayName"   : "Normal Texture",
            "name"          : "normalTexture",
            "type"          : "texture",
            "value"         : "",
            "uniform"       : "u_normalTex",
            "toggle"        : "u_useNormalTex"
        }, {
            "displayName"   : "Normal Intensity",
            "name"          : "normalIntensity",
            "type"          : "float",
            "value"         : 1,
            "min"           : -1,
            "max"           : 1,
            "uniform"       : "u_normalIntensity"
        }, {
            "displayName"   : "Scroll Speed",
            "name"          : "scrollSpeed",
            "type"          : "float",
            "value"         : 0.05,
            "min"           : 0.0,
            "max"           : 2,
            "uniform"       : "u_scrollSpeed"
        }, {
            "displayName"   : "Alpha",
            "name"          : "alpha",
            "type"          : "float",
            "value"         : 0.5,
            "min"           : 0,
            "max"           : 1,
            "uniform"       : "u_alpha"
        }, {
            "displayName"   : "Reflection Texture",
            "name"          : "reflectionTexture",
            "type"          : "texture",
            "value"         : "",
            "uniform"       : "u_reflectionTex",
            "toggle"        : "u_useReflectionTex"
        }, {
            "displayName"   : "Reflection Intensity",
            "name"          : "reflectionIntensity",
            "type"          : "float",
            "value"         : 1,
            "min"           : -1,
            "max"           : 1,
            "uniform"       : "u_reflectionIntensity"
        }
    ],
    "vertex_shader":":assets/shaders/surface.vert",
    "fragment_shader": "water.frag"
}